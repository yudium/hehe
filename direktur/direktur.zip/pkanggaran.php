<?php
	session_start();
  ob_start();
  include("libfunc.php");
  include("../libfunc.php");
  $link=koneksidb();
  if(($_SESSION['logadm']==true) && ($_SESSION['useradm']!="")){
    $kdpos=$_POST['NSdeBK'];
    echo $kdpos;
  	$sql3="UPDATE bebanperusahaan SET status='Y' WHERE kd_bebanperusahaan='$kdpos'";
    $res3=mysqli_query($link,$sql3);
    if($res3){
      echo "<script>alert('Data Beban Biaya Telah Diverifikasi');
                   document.location.href='kbebanbiaya';</script>";
    }
  }else{
    header("Location: ../masuk.php");
	}
?>