<?php
session_start();
ob_start();
include("libfunc.php");
include("../libfunc.php");
$link=koneksidb();
if(($_SESSION['logadm']==true) && ($_SESSION['useradm']!="")){
  $usermin=$_SESSION['useradm'];
  $iduser=$_SESSION['idadm'];
  $sql3="SELECT * FROM pengguna WHERE id_pengguna='$iduser'";
  $res3=mysqli_query($link,$sql3);
  $data3=mysqli_fetch_array($res3);
  headmin();
  $tahun=date('Y');
?>
    <!--inner block start here-->
    <div class="inner-block">
      <div class="table-agile-info">
  <div class="panel panel-default">
    <div class="chit-chat-heading">
      Persentase Beban Biaya
    </div>
    <div class="table-responsive">
      <table class="table table-hover">
        <thead>
          <tr>
            <th style="width:20px;"><center>No</center></th>
            <th><center>Jenis Beban</center></th>
            <th><center>Jumlah Beban</center></th>
            <th><center>Persentase</center></th>
          </tr>
        </thead>
        <tbody>
          <?php
          $sql1="SELECT *, dp.kd_bebanperusahaan AS kd_bebanperusahaan FROM detilbebanperusahaan dp INNER JOIN jenisrekap jr ON dp.kd_jenisrekap=jr.kd_jenisrekap INNER JOIN bebanperusahaan pa ON dp.kd_bebanperusahaan=pa.kd_bebanperusahaan WHERE dp.kd_bebanperusahaan LIKE '%$tahun%'";
          $res1=mysqli_query($link,$sql1);

          $sql2="SELECT *, SUM(jumlahbebanperusahaan) AS total FROM detilbebanperusahaan WHERE kd_bebanperusahaan LIKE '%$tahun%' GROUP BY kd_bebanperusahaan";
          $res2=mysqli_query($link,$sql2);
          $data2=mysqli_fetch_array($res2);
          $i=1;
          $jum=0;
          while($data1=mysqli_fetch_array($res1)){
            // $format = date('d F Y', strtotime($data1['tanggal']));
            $persentase=round(($data1['jumlahbebanperusahaan']/$data2['total']*100),2);
          ?>
          <tr>
            <td><center><?php echo $i;?></center></td>
            <td><center><?php echo $data1['jenisrekap'];?></center></td>
            <td><center><?php echo "Rp ".number_format($data1['jumlahbebanperusahaan']);?></center></td>
            <td><center><?php echo $persentase." %";?></center></td>
          </tr>
          </div>
          <?php
          $jum=$jum+$persentase;
          $persentase=0;
          $i++;
          }
          ?>
          <tr>
            <td colspan="2"><center><b>Total</b></center></td>
            <td><center><?php echo "Rp ".number_format($data2['total']); ?></center></td>
            <td><center><?php echo $jum." %"; ?></center></td>
        </tbody>
      </table>
      <br>
    </div>
  </div>
</div>
</div>
</div>
</div>
<?php
sidemin();
}else{
  header("Location: ../masuk.php");
}
ob_flush();
?>