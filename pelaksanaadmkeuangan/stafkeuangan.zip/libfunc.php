<?php
function headske(){
	$iduser=$_SESSION['idske'];
	$link=koneksidb();
	$sql="SELECT * FROM pengguna pg INNER JOIN pegawai p ON pg.id_pegawai=p.id_pegawai WHERE id_pengguna='$iduser'";
	$res=mysqli_query($link,$sql);
	$data=mysqli_fetch_array($res);
	?>
	<!DOCTYPE HTML>
<html>
<head>
	<title>PT TATA DIMENSI PANCARINDO</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Shoppy Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
	Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
	<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	<link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all">
	<!-- Custom Theme files -->
	<link href="../css/style.css" rel="stylesheet" type="text/css" media="all"/>
	<!--js-->
	<script src="../js/jquery-2.1.1.min.js"></script> 
	<!--icons-css-->
	<link href="../css/font-awesome.css" rel="stylesheet"> 
	<!--Google Fonts-->
	<link href='//fonts.googleapis.com/css?family=Carrois+Gothic' rel='stylesheet' type='text/css'>
	<link href='//fonts.googleapis.com/css?family=Work+Sans:400,500,600' rel='stylesheet' type='text/css'>
	<!--static chart-->
	<script src="../js/Chart.min.js"></script>
	<!--//charts-->
	<!--skycons-icons-->
	<script src="../js/skycons.js"></script>
	<!--//skycons-icons-->
</head>
<body>	
	<div class="page-container">	
		<div class="left-content">
			<div class="mother-grid-inner">
				<!--header start here-->
				<div class="header-main">
					<div class="header-left">
						<div class="logo-name">
							<a href="index.html"> 
								<img id="logo" src="../images/logoo.png" alt="Logo"/> </a>

							</div>

							<div class="clearfix"> </div>
						</div>
						<div class="header-right">
							<div class="profile_details">		
								<ul>
									<li class="dropdown profile_details_drop">
										<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
											<div class="profile_img">	
												<!-- <span class="prfil-img"><img src="images/p1.png" alt=""> </span>  -->
												<div class="user-name">
													<p><?php echo $data['nama'];?></p>
													<span><?php echo $data['level'];?></span>
												</div>
												<i class="fa fa-angle-down lnr"></i>
												<i class="fa fa-angle-up lnr"></i>
												<div class="clearfix"></div>	
											</div>	
										</a>
										<ul class="dropdown-menu drp-mnu">
											<li> <a href="ukatasandi"><i class="fa fa-cog"></i>Ubah Kata Sandi</a> </li>
											<li> <a href="../logout"><i class="fa fa-sign-out"></i> Logout</a> </li>
										</ul>
									</li>
								</ul>
							</div>
							<div class="clearfix"> </div>				
						</div>
						<div class="clearfix"> </div>	
					</div>
					<!--heder end here-->
					<!-- script-for sticky-nav -->
					<script>
						$(document).ready(function() {
							var navoffeset=$(".header-main").offset().top;
							$(window).scroll(function(){
								var scrollpos=$(window).scrollTop(); 
								if(scrollpos >=navoffeset){
									$(".header-main").addClass("fixed");
								}else{
									$(".header-main").removeClass("fixed");
								}
							});

						});
					</script>
					<!-- /script-for sticky-nav -->
			<?php
		}
		function sideske(){
			?>
			<div class="sidebar-menu">
				<div class="logo"> <a href="#" class="sidebar-icon"> <span class="fa fa-bars"></span> </a> <a href="#"> <span id="logo" ></span> 
					<!--<img id="logo" src="" alt="Logo"/>--> 
				</a> </div>		  
				<div class="menu">
					<ul id="menu" >
						<li id="menu-home" ><a href="index"><i class="fa fa-tachometer"></i><span>Beranda</span></a></li>
						<li><a href="pengguna"><i class="fa fa-users"></i><span>Pengguna</span></a></li>
						<li><a href="pegawai"><i class="fa fa-users"></i><span>Pegawai</span></a></li>
						<li><a href="kas"><i class="fa fa-usd"></i><span>Penambahan Kas</span></a></li>
						<li><a href="bukubesar"><i class="fa fa-file"></i><span>Buku Besar</span></a></li>
						</li>
					</ul>
				</div>
			</div>
			<div class="clearfix"> </div>
		</div>
		<!--slide bar menu end here-->
		<script>
			var toggle = true;

			$(".sidebar-icon").click(function() {                
				if (toggle)
				{
					$(".page-container").addClass("sidebar-collapsed").removeClass("sidebar-collapsed-back");
					$("#menu span").css({"position":"absolute"});
				}
				else
				{
					$(".page-container").removeClass("sidebar-collapsed").addClass("sidebar-collapsed-back");
					setTimeout(function() {
						$("#menu span").css({"position":"relative"});
					}, 400);
				}               
				toggle = !toggle;
			});
		</script>
		<!--scrolling js-->
		<!-- <script src="js/jquery.nicescroll.js"></script> -->
		<script src="../js/scripts.js"></script>
		<!--//scrolling js-->
		<script src="../js/bootstrap.js"> </script>
		<!-- mother grid end here-->
	</body>
	</html>                     
			<?php
		}
		function mainskeu(){
			headske();
			$link=koneksidb();
	?>
	<!--inner block start here-->
	<div class="inner-block">
		<div class="table-agile-info">
			<div class="panel panel-default">
        <div class="chit-chat-heading">
          Modal Biaya Tahun 2017
        </div>
        <br>
				<div class="chit-chat-heading">
					<?php
					$sql="SELECT SUM(jumlahpendapatan) AS pendapatan FROM pendapatan WHERE tanggal LIKE '%2016%' AND kd_pendapatan LIKE '%PDP%'";
					$res=mysqli_query($link,$sql);
					$data=mysqli_fetch_array($res);

					$sql2="SELECT SUM(kredit) AS total FROM kasbesar k INNER JOIN jenisrekap j ON k.kd_jenisrekap=j.kd_jenisrekap WHERE tanggal LIKE '%2016%' AND k.kd_jenisrekap!='RK04' GROUP BY SUBSTR(k.kd_jenisrekap,1,2)";
					$res2=mysqli_query($link,$sql2);
					$data2=mysqli_fetch_array($res2);

					$laba=$data['pendapatan']-$data2['total'];

					$sql4="SELECT * FROM pendapatan WHERE kd_pendapatan LIKE '%PLUB%' AND SUBSTR(tanggal,1,4)='2016'";
					$res4=mysqli_query($link,$sql4);
					$data4=mysqli_fetch_array($res4);

					$sql44="SELECT * FROM pendapatan WHERE kd_pendapatan LIKE '%PLUP%' AND SUBSTR(tanggal,1,4)='2016'";
					$res44=mysqli_query($link,$sql44);
					$data44=mysqli_fetch_array($res44);

					$totlaba=$laba+$data4['jumlahpendapatan']+$data44['jumlahpendapatan'];
// echo $totlaba;
					?>
					<table class="table table-hover">
						<thead>
							<tr>
								<th style="width:20px;"><center>No</center></th>
								<th><center>Jenis Rekap</center></th>
								<th><center>Rencana Pos Anggaran</center></th>
								<th><center>Laba 2016 Sebelum Pajak</center></th>
								<th><center>Persentase</center></th>
							</tr>
						</thead>
						<tbody>
							<?php
							$sql1="SELECT * FROM bebanperusahaan p INNER JOIN detilbebanperusahaan d ON p.kd_bebanperusahaan=d.kd_bebanperusahaan INNER JOIN jenisrekap j ON d.kd_jenisrekap=j.kd_jenisrekap WHERE p.kd_bebanperusahaan LIKE '%2017%'";
							$res1=mysqli_query($link,$sql1);
							$i=1;
							while($data1=mysqli_fetch_array($res1)){
								$pers=$data1['jumlahbebanperusahaan']/$totlaba*100;
								$ar[$i]=$data1['jumlahbebanperusahaan'];
								$ar1[$i]=$pers;
								?>
								<tr>
									<td><center><?php echo $i;?></center></td>
									<td><center><?php echo strtoupper($data1['jenisrekap']);?></center></td>
									<td><center><?php echo "Rp ".strtoupper(number_format($data1['jumlahbebanperusahaan']));?></center></td>
									<td><center><?php echo "Rp ".strtoupper(number_format($totlaba));?></center></td>
									<td><center><?php echo round($pers,2)." %"; ?></center></td>
								</tr>
									<?php
									$i++;
								}
								$totalbeban=array_sum($ar);
								$totalpers=array_sum($ar1);
								$pkas=100-$totalpers;
							$kas=($pkas/100)*$totalbeban;
							?>
							<tr>
								<td colspan="2"><center>TOTAL</center></td>
								<td><center><?php echo "Rp ".strtoupper(number_format($totalbeban));?></center></td>
								<td><center><?php echo "Rp ".strtoupper(number_format($totlaba));?></center></td>
								<td><center><?php echo round($totalpers,2)." %"; ?></center></td>
							</tr>
							<tr>
								<td colspan="2"><center>KAS</center></td>
								<td><center><?php echo "Rp ".strtoupper(number_format($kas));?></center></td>
								<td><center><?php echo "Rp ".strtoupper(number_format($totlaba));?></center></td>
								<td><center><?php echo round($pkas,2)." %"; ?></center></td>
							</tr>
							</tbody>
						</table>
					</center>
				</div>
			</div>
		</div>
	</div>
	<!--inner block end here-->
	<!--copy rights start here-->
	<div class="copyrights">
		<p>© Design by  <a href="http://w3layouts.com/" target="_blank">W3layouts</a> </p>
	</div>	
	<!--COPY rights end here-->
</div>
</div>
<?php
			sideske();
}
?>