<?php
  session_start();
  ob_start();
  date_default_timezone_set('Asia/Jakarta');
  include("libfunc.php");
  include("../libfunc.php");
  $link=koneksidb();
  if(($_SESSION['logmanke']==true) && ($_SESSION['usermanke']!="")){
    $usermin=$_SESSION['usermanke'];
    $iduser=$_SESSION['idmanke'];
    $sql3="SELECT * FROM pengguna WHERE id_pengguna='$iduser'";
    $res3=mysqli_query($link,$sql3);
    $data3=mysqli_fetch_array($res3);
    headmanke();
    $thn1=date('Y');
    $min11=date('Y', strtotime('-1 year', strtotime($thn1)));
    $min22=date('Y', strtotime('-2 year', strtotime($thn1)));
?>
    <!--inner block start here-->
    <div class="inner-block">
      <div class="table-agile-info">
  <div class="panel panel-default">
    <div class="chit-chat-heading">
      Rencana Beban Biaya Perusahaan
    </div>
    <form class="form-horizontal style-form" role="form" method="post" action="">
    <div class="table-responsive">
      <table class="table table-hover">
        <thead>
          <tr>
            <th style="width:20px;"><center>No</center></th>
            <th><center>Jenis Rekap</center></th>
            <th><center>Realisasi <?php echo $min22; ?></center></th>
            <th><center>Realisasi <?php echo $min11; ?></center></th>
            <th><center>Rencara <?php echo $thn1; ?></center></th>
          </tr>
        </thead>
        <tbody>
          <?php
          $sql1="SELECT * FROM jenisrekap WHERE kd_jenisrekap!='RK04' ORDER BY kd_jenisrekap";
          $res1=mysqli_query($link,$sql1);
          $thn=date('Y');
          $i=1;
          while($data1=mysqli_fetch_array($res1)){
            $min1=date('Y', strtotime('-1 year', strtotime($thn)));
            $sql2="SELECT *, SUM(kredit) AS krr FROM kasbesar WHERE tanggal LIKE '%$min1%' AND kd_jenisrekap='$data1[kd_jenisrekap]' GROUP BY kd_jenisrekap";
            $res2=mysqli_query($link,$sql2);
            $data2=mysqli_fetch_array($res2);

            $min2=date('Y', strtotime('-2 year', strtotime($thn)));
            $sql4="SELECT *, SUM(kredit) AS krr FROM kasbesar WHERE tanggal LIKE '%$min2%' AND kd_jenisrekap='$data1[kd_jenisrekap]' GROUP BY kd_jenisrekap";
            $res4=mysqli_query($link,$sql4);
            $data4=mysqli_fetch_array($res4);

            //rumus pos anggaran (persen)
            $pers=round(abs(($data2['krr']-$data4['krr'])/$data4['krr']*100));

            //rumus pos anggaran
            $posang=ceil($data2['krr']+($data2['krr']*($pers/100)));

            //masuk ke dalam array
            $posanggaran[$i]=$posang;
            $kdrekap[$i]=$data1['kd_jenisrekap'];
          ?>
          <tr>
            <td><center><?php echo $i;?></center></td>
            <td><center><?php echo $data1['jenisrekap'];?></center></td>
            <td><center><?php echo "Rp ".number_format($data4['krr']);?></center></td>
            <td><center><?php echo "Rp ".number_format($data2['krr']);?></center></td>
            <td><center><?php echo "Rp ".number_format($posang);?></center></td>
          </tr>
          <?php
          $i++;
          }
          ?>
        </tbody>
      </table>
      <br>
      <?php 
        $sql2="SELECT * FROM bebanperusahaan WHERE kd_bebanperusahaan LIKE '%$thn1%'";
        $res2=mysqli_query($link,$sql2);
        $has=mysqli_num_rows($res2);
        if($has==0){
        ?>
          <input type="submit" value="Simpan" name="submit" class="btn btn-default">
        <?php 
        }else{
          echo " "; 
        }
         ?>
    </div>
  </form>
  <?php 
  if (isset($_POST["submit"])){
    $loop=count($posanggaran);
    $tanggall=date("Y-m-d H:i:s");
    $kode="PSA".$thn;
    $sql5="INSERT INTO bebanperusahaan VALUES('$kode','$tanggall','$thn','T')";
    $res5=mysqli_query($link,$sql5);
    // echo $kode." ".$tanggall." ".$thn."<br>";
    for($j=1;$j<=$loop;$j++){
      $sql6="INSERT INTO detilbebanperusahaan VALUES('$kode','$kdrekap[$j]','$posanggaran[$j]')";
      $res6=mysqli_query($link,$sql6);
      // echo $kode." ".$kdrekap[$j]." ".$posanggaran[$j]."<br>";
    }
    echo "<script>alert('Data Berhasil Ditambahkan');
                  document.location.href='badgeting.php';</script>";
  }


   ?>
  </div>
</div>
</div>
</div>
</div>
<?php
    sidemanke();
}else{
    header("Location: ../masuk.php");
}
ob_flush();
?>



