<?php
	session_start();
  ob_start();
  include("libfunc.php");
  include("../libfunc.php");
  $link=koneksidb();
  if(($_SESSION['logmanke']==true) && ($_SESSION['usermanke']!="")){
    $nama=$_POST['nama'];
    $kdjen=$_POST['frUKBfe'];
  	$sql3="UPDATE jenisrekap SET jenisrekap='$nama' WHERE kd_jenisrekap='$kdjen'";
    $res3=mysqli_query($link,$sql3);
    if($res3){
      echo "<script>alert('Data Berhasil Diubah');
                   document.location.href='jenisrekap';</script>";
    }
  }else{
    header("Location: ../masuk.php");
	}
?>