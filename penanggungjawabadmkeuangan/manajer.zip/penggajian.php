<?php
session_start();
ob_start();
date_default_timezone_set('Asia/Jakarta');
include("libfunc.php");
include("../libfunc.php");
$link=koneksidb();
if(($_SESSION['logmanke']==true) && ($_SESSION['usermanke']!="")){
  $usermin=$_SESSION['usermanke'];
  $iduser=$_SESSION['idmanke'];
  $sql3="SELECT * FROM pengguna WHERE id_pengguna='$iduser'";
  $res3=mysqli_query($link,$sql3);
  $data3=mysqli_fetch_array($res3);
  headmanke();
  $tahun=date('Y');
  $bulan=date('F');
  // $mb=15000000;
  ?>
  <script type="text/javascript">
    function validate(){
      var error="";
      <?php 
      $sql2="SELECT * FROM pegawai";
      $res2=mysqli_query($link,$sql2);
      while($data2=mysqli_fetch_array($res2)){
        $sql5="SELECT SUM(jumlahbonus) AS jumbon FROM bonus WHERE id_pegawai='$data2[id_pegawai]' AND tanggal LIKE '%$tahun%'";
        $res5=mysqli_query($link,$sql5);
        $data5=mysqli_fetch_array($res5);
        $sisa=$data2['bonus']-$data5['jumbon'];
        ?>
        var bonus<?php echo $data2['id_pegawai'];?> = document.getElementById( "bonus<?php echo $data2['id_pegawai'];?>" );
        if( bonus<?php echo $data2['id_pegawai'];?>.value > <?php echo $sisa; ?> ){
          error = alert('Bonus Melebihi Batas Periode!');
          document.getElementById( "error_para" ).innerHTML = error;
          return false;
        }
        <?php
      }
      ?>
      
      var kasbon = document.getElementById( "kasbon" );
      if( kasbon.value == "" ){
        error = alert('Lengkapi Form !');
        document.getElementById( "error_para" ).innerHTML = error;
        return false;
      }else{
        return true;
      }
    }
  </script>
  <!--inner block start here-->
  <div class="inner-block">
    <div class="table-agile-info">
      <div class="panel panel-default">
        <div class="chit-chat-heading">
          Penggajian Bulan <?php echo $bulan; ?>
        </div>
        <br>
        <form class="form-horizontal style-form" role="form" method="post" action="" onsubmit="return validate();">
          <table class="table table-hover">
                <thead>
                  <tr>
                    <th style="width:20px;"><center>No</center></th>
                    <th><center>Nama</center></th>
                    <th><center>Gaji</center></th>
                    <th><center>Bonus</center></th>
                    <th><center>Kasbon</center></th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  $sql1="SELECT * FROM pegawai p INNER JOIN gaji g ON p.id_pegawai=g.id_pegawai";
                  $res1=mysqli_query($link,$sql1);
                  $i=1;
                  while($data1=mysqli_fetch_array($res1)){
                    $sql6="SELECT SUM(jumlahbonus) AS jumbon FROM bonus WHERE id_pegawai='$data1[id_pegawai]' AND tanggal LIKE '%$tahun%'";
                    $res6=mysqli_query($link,$sql6);
                    $data6=mysqli_fetch_array($res6);
                    $sisa1=$data1['bonus']-$data6['jumbon'];
                    ?>
                    <tr>
                      <td><center><?php echo $i;?></center></td>
                      <td><center><?php echo strtoupper($data1['nama']);?></center></td>
                      <td><center><?php echo "Rp ".strtoupper(number_format($data1['gaji']))?></center></td>
                      <td><center><input class="form-control" placeholder="<?php echo number_format($sisa1); ?>" id="bonus<?php echo $data1['id_pegawai'];?>" type="number" name="bonus<?php echo $data1['id_pegawai'];?>"></center></td>
                      <td><center><input class="form-control" id="kasbon<?php echo $data1['id_pegawai'];?>" type="number" name="kasbon<?php echo $data1['id_pegawai'];?>"></center></td>
                    </tr>
                    <?php
                    $idsem[$i]=$data1['id_pegawai'];
                    $i++;
                  }
                  ?>
                </table>
                <hr> 
                <?php 
                  $tglcek=date('Y-m');
                  $sqll4="SELECT * FROM kasbesar WHERE kd_jenisrekap='RK02' AND tanggal LIKE '%$tglcek%'";
                  $ress4=mysqli_query($link,$sqll4);
                  if(mysqli_num_rows($ress4)==0){
                   echo "<input type='submit' value='Proses' name='submit' class='btn btn-default'>";
                  }else{
                    echo "";
                  }
                 ?>
        </form>
        <p style="display:none" id="error_para"></p>
        <br>
        <br>
        <?php 
          if (isset($_POST["submit"])){
            $sql4="SELECT * FROM pegawai p INNER JOIN gaji g ON p.id_pegawai=g.id_pegawai";
            $res4=mysqli_query($link,$sql4);
            $o=1;
            while($data4=mysqli_fetch_array($res4)){
              if($data4['id_pegawai']=='pp1'){
                $bonuspp1=$_POST['bonuspp1'];
                $kasbonpp1=$_POST['kasbonpp1'];
                $gaji=$data4['gaji']+$bonuspp1-$kasbonpp1;
                $sql7="SELECT *, CONVERT(SUBSTR(kd_kasbesar,3,9), SIGNED) AS kode FROM kasbesar WHERE tanggal IN (SELECT MAX(tanggal) FROM kasbesar) ORDER BY kd_kasbesar DESC LIMIT 1";
                $res7=mysqli_query($link,$sql7);
                $data7=mysqli_fetch_array($res7);

                $kode="TD".($data7['kode']+1);
                $saldo=$data7['saldo']-$gaji;
                $keterangan1="Gaji ".$data4['nama'];
                $tanggal=date("Y-m-d H:i:s");
                $tgl=date("Y-m-d");

                $sqll="INSERT INTO kasbesar VALUES ('$kode','$tanggal','$keterangan1','0','$gaji','$saldo','RK02','PDP00000')";
                $ress=mysqli_query($link,$sqll);

                $sqlll="INSERT INTO bonus VALUES('$data4[id_pegawai]','$tgl','$bonuspp1')";
                $resss=mysqli_query($link,$sqlll);

                $sqll1="INSERT INTO kasbon VALUES('$data4[id_pegawai]','$tgl','$kasbonpp1')";
                $ress1=mysqli_query($link,$sqll1);
                // echo $data4['id_pegawai']." ".$gaji." ".$saldo."<br>";

              }
              if($data4['id_pegawai']=='pp2'){
                $bonuspp2=$_POST['bonuspp2'];
                $kasbonpp2=$_POST['kasbonpp2'];
                $gaji=$data4['gaji']+$bonuspp2-$kasbonpp2;
                $sql7="SELECT *, CONVERT(SUBSTR(kd_kasbesar,3,9), SIGNED) AS kode FROM kasbesar WHERE tanggal IN (SELECT MAX(tanggal) FROM kasbesar) ORDER BY kd_kasbesar DESC LIMIT 1";
                $res7=mysqli_query($link,$sql7);
                $data7=mysqli_fetch_array($res7);

                $kode="TD".($data7['kode']+1);
                $saldo=$data7['saldo']-$gaji;
                $keterangan1="Gaji ".$data4['nama'];
                $tanggal=date("Y-m-d H:i:s");
                $tgl=date("Y-m-d");

                $sqll="INSERT INTO kasbesar VALUES ('$kode','$tanggal','$keterangan1','0','$gaji','$saldo','RK02','PDP00000')";
                $ress=mysqli_query($link,$sqll);

                $sqlll="INSERT INTO bonus VALUES('$data4[id_pegawai]','$tgl','$bonuspp2')";
                $resss=mysqli_query($link,$sqlll);

                $sqll1="INSERT INTO kasbon VALUES('$data4[id_pegawai]','$tgl','$kasbonpp2')";
                $ress1=mysqli_query($link,$sqll1);
                // echo $data4['id_pegawai']." ".$gaji." ".$saldo."<br>";

              }
              if($data4['id_pegawai']=='pp3'){
                $bonuspp3=$_POST['bonuspp3'];
                $kasbonpp3=$_POST['kasbonpp3'];
                $gaji=$data4['gaji']+$bonuspp3-$kasbonpp3;
                $sql7="SELECT *, CONVERT(SUBSTR(kd_kasbesar,3,9), SIGNED) AS kode FROM kasbesar WHERE tanggal IN (SELECT MAX(tanggal) FROM kasbesar) ORDER BY kd_kasbesar DESC LIMIT 1";
                $res7=mysqli_query($link,$sql7);
                $data7=mysqli_fetch_array($res7);

                $kode="TD".($data7['kode']+1);
                $saldo=$data7['saldo']-$gaji;
                $keterangan1="Gaji ".$data4['nama'];
                $tanggal=date("Y-m-d H:i:s");
                $tgl=date("Y-m-d");

                $sqll="INSERT INTO kasbesar VALUES ('$kode','$tanggal','$keterangan1','0','$gaji','$saldo','RK02','PDP00000')";
                $ress=mysqli_query($link,$sqll);

                $sqlll="INSERT INTO bonus VALUES('$data4[id_pegawai]','$tgl','$bonuspp3')";
                $resss=mysqli_query($link,$sqlll);

                $sqll1="INSERT INTO kasbon VALUES('$data4[id_pegawai]','$tgl','$kasbonpp3')";
                $ress1=mysqli_query($link,$sqll1);
                // echo $data4['id_pegawai']." ".$gaji." ".$saldo."<br>";

              }
              if($data4['id_pegawai']=='pp4'){
                $bonuspp4=$_POST['bonuspp4'];
                $kasbonpp4=$_POST['kasbonpp4'];
                $gaji=$data4['gaji']+$bonuspp4-$kasbonpp4;
                $sql7="SELECT *, CONVERT(SUBSTR(kd_kasbesar,3,9), SIGNED) AS kode FROM kasbesar WHERE tanggal IN (SELECT MAX(tanggal) FROM kasbesar) ORDER BY kd_kasbesar DESC LIMIT 1";
                $res7=mysqli_query($link,$sql7);
                $data7=mysqli_fetch_array($res7);

                $kode="TD".($data7['kode']+1);
                $saldo=$data7['saldo']-$gaji;
                $keterangan1="Gaji ".$data4['nama'];
                $tanggal=date("Y-m-d H:i:s");
                $tgl=date("Y-m-d");

                $sqll="INSERT INTO kasbesar VALUES ('$kode','$tanggal','$keterangan1','0','$gaji','$saldo','RK02','PDP00000')";
                $ress=mysqli_query($link,$sqll);

                $sqlll="INSERT INTO bonus VALUES('$data4[id_pegawai]','$tgl','$bonuspp4')";
                $resss=mysqli_query($link,$sqlll);

                $sqll1="INSERT INTO kasbon VALUES('$data4[id_pegawai]','$tgl','$kasbonpp4')";
                $ress1=mysqli_query($link,$sqll1);
                // echo $data4['id_pegawai']." ".$gaji." ".$saldo."<br>";

              }
              if($data4['id_pegawai']=='pp5'){
                $bonuspp5=$_POST['bonuspp5'];
                $kasbonpp5=$_POST['kasbonpp5'];
                $gaji=$data4['gaji']+$bonuspp5-$kasbonpp5;
                $sql7="SELECT *, CONVERT(SUBSTR(kd_kasbesar,3,9), SIGNED) AS kode FROM kasbesar WHERE tanggal IN (SELECT MAX(tanggal) FROM kasbesar) ORDER BY kd_kasbesar DESC LIMIT 1";
                $res7=mysqli_query($link,$sql7);
                $data7=mysqli_fetch_array($res7);

                $kode="TD".($data7['kode']+1);
                $saldo=$data7['saldo']-$gaji;
                $keterangan1="Gaji ".$data4['nama'];
                $tanggal=date("Y-m-d H:i:s");
                $tgl=date("Y-m-d");

                $sqll="INSERT INTO kasbesar VALUES ('$kode','$tanggal','$keterangan1','0','$gaji','$saldo','RK02','PDP00000')";
                $ress=mysqli_query($link,$sqll);

                $sqlll="INSERT INTO bonus VALUES('$data4[id_pegawai]','$tgl','$bonuspp5')";
                $resss=mysqli_query($link,$sqlll);

                $sqll1="INSERT INTO kasbon VALUES('$data4[id_pegawai]','$tgl','$kasbonpp5')";
                $ress1=mysqli_query($link,$sqll1);
                // echo $data4['id_pegawai']." ".$gaji." ".$saldo."<br>";

              }
              if($data4['id_pegawai']=='pp6'){
                $bonuspp6=$_POST['bonuspp6'];
                $kasbonpp6=$_POST['kasbonpp6'];
                $gaji=$data4['gaji']+$bonuspp6-$kasbonpp6;
                $sql7="SELECT *, CONVERT(SUBSTR(kd_kasbesar,3,9), SIGNED) AS kode FROM kasbesar WHERE tanggal IN (SELECT MAX(tanggal) FROM kasbesar) ORDER BY kd_kasbesar DESC LIMIT 1";
                $res7=mysqli_query($link,$sql7);
                $data7=mysqli_fetch_array($res7);

                $kode="TD".($data7['kode']+1);
                $saldo=$data7['saldo']-$gaji;
                $keterangan1="Gaji ".$data4['nama'];
                $tanggal=date("Y-m-d H:i:s");
                $tgl=date("Y-m-d");

                $sqll="INSERT INTO kasbesar VALUES ('$kode','$tanggal','$keterangan1','0','$gaji','$saldo','RK02','PDP00000')";
                $ress=mysqli_query($link,$sqll);

                $sqlll="INSERT INTO bonus VALUES('$data4[id_pegawai]','$tgl','$bonuspp6')";
                $resss=mysqli_query($link,$sqlll);

                $sqll1="INSERT INTO kasbon VALUES('$data4[id_pegawai]','$tgl','$kasbonpp6')";
                $ress1=mysqli_query($link,$sqll1);
                // echo $data4['id_pegawai']." ".$gaji." ".$saldo."<br>";

              }
              if($data4['id_pegawai']=='pp7'){
                $bonuspp7=$_POST['bonuspp7'];
                $kasbonpp7=$_POST['kasbonpp7'];
                $gaji=$data4['gaji']+$bonuspp7-$kasbonpp7;
                $sql7="SELECT *, CONVERT(SUBSTR(kd_kasbesar,3,9), SIGNED) AS kode FROM kasbesar WHERE tanggal IN (SELECT MAX(tanggal) FROM kasbesar) ORDER BY kd_kasbesar DESC LIMIT 1";
                $res7=mysqli_query($link,$sql7);
                $data7=mysqli_fetch_array($res7);

                $kode="TD".($data7['kode']+1);
                $saldo=$data7['saldo']-$gaji;
                $keterangan1="Gaji ".$data4['nama'];
                $tanggal=date("Y-m-d H:i:s");
                $tgl=date("Y-m-d");

                $sqll="INSERT INTO kasbesar VALUES ('$kode','$tanggal','$keterangan1','0','$gaji','$saldo','RK02','PDP00000')";
                $ress=mysqli_query($link,$sqll);

                $sqlll="INSERT INTO bonus VALUES('$data4[id_pegawai]','$tgl','$bonuspp7')";
                $resss=mysqli_query($link,$sqlll);

                $sqll1="INSERT INTO kasbon VALUES('$data4[id_pegawai]','$tgl','$kasbonpp7')";
                $ress1=mysqli_query($link,$sqll1);
                // echo $data4['id_pegawai']." ".$gaji." ".$saldo."<br>";

              }
              if($data4['id_pegawai']=='pp8'){
                $bonuspp8=$_POST['bonuspp8'];
                $kasbonpp8=$_POST['kasbonpp8'];
                $gaji=$data4['gaji']+$bonuspp8-$kasbonpp8;
                $sql7="SELECT *, CONVERT(SUBSTR(kd_kasbesar,3,9), SIGNED) AS kode FROM kasbesar WHERE tanggal IN (SELECT MAX(tanggal) FROM kasbesar) ORDER BY kd_kasbesar DESC LIMIT 1";
                $res7=mysqli_query($link,$sql7);
                $data7=mysqli_fetch_array($res7);

                $kode="TD".($data7['kode']+1);
                $saldo=$data7['saldo']-$gaji;
                $keterangan1="Gaji ".$data4['nama'];
                $tanggal=date("Y-m-d H:i:s");
                $tgl=date("Y-m-d");

                $sqll="INSERT INTO kasbesar VALUES ('$kode','$tanggal','$keterangan1','0','$gaji','$saldo','RK02','PDP00000')";
                $ress=mysqli_query($link,$sqll);

                $sqlll="INSERT INTO bonus VALUES('$data4[id_pegawai]','$tgl','$bonuspp8')";
                $resss=mysqli_query($link,$sqlll);

                $sqll1="INSERT INTO kasbon VALUES('$data4[id_pegawai]','$tgl','$kasbonpp8')";
                $ress1=mysqli_query($link,$sqll1);
                // echo $data4['id_pegawai']." ".$gaji." ".$saldo."<br>";

              }
              if($data4['id_pegawai']=='pp9'){
                $bonuspp9=$_POST['bonuspp9'];
                $kasbonpp9=$_POST['kasbonpp9'];
                $gaji=$data4['gaji']+$bonuspp9-$kasbonpp9;
                $sql7="SELECT *, CONVERT(SUBSTR(kd_kasbesar,3,9), SIGNED) AS kode FROM kasbesar WHERE tanggal IN (SELECT MAX(tanggal) FROM kasbesar) ORDER BY kd_kasbesar DESC LIMIT 1";
                $res7=mysqli_query($link,$sql7);
                $data7=mysqli_fetch_array($res7);

                $kode="TD".($data7['kode']+1);
                $saldo=$data7['saldo']-$gaji;
                $keterangan1="Gaji ".$data4['nama'];
                $tanggal=date("Y-m-d H:i:s");
                $tgl=date("Y-m-d");

                $sqll="INSERT INTO kasbesar VALUES ('$kode','$tanggal','$keterangan1','0','$gaji','$saldo','RK02','PDP00000')";
                $ress=mysqli_query($link,$sqll);

                $sqlll="INSERT INTO bonus VALUES('$data4[id_pegawai]','$tgl','$bonuspp9')";
                $resss=mysqli_query($link,$sqlll);

                $sqll1="INSERT INTO kasbon VALUES('$data4[id_pegawai]','$tgl','$kasbonpp9')";
                $ress1=mysqli_query($link,$sqll1);
                // echo $data4['id_pegawai']." ".$gaji." ".$saldo."<br>";

              }
              if($data4['id_pegawai']=='pp10'){
                $bonuspp10=$_POST['bonuspp10'];
                $kasbonpp10=$_POST['kasbonpp10'];
                $gaji=$data4['gaji']+$bonuspp10-$kasbonpp10;
                $sql7="SELECT *, CONVERT(SUBSTR(kd_kasbesar,3,9), SIGNED) AS kode FROM kasbesar WHERE tanggal IN (SELECT MAX(tanggal) FROM kasbesar) ORDER BY kd_kasbesar DESC LIMIT 1";
                $res7=mysqli_query($link,$sql7);
                $data7=mysqli_fetch_array($res7);

                $kode="TD".($data7['kode']+1);
                $saldo=$data7['saldo']-$gaji;
                $keterangan1="Gaji ".$data4['nama'];
                $tanggal=date("Y-m-d H:i:s");
                $tgl=date("Y-m-d");

                $sqll="INSERT INTO kasbesar VALUES ('$kode','$tanggal','$keterangan1','0','$gaji','$saldo','RK02','PDP00000')";
                $ress=mysqli_query($link,$sqll);

                $sqlll="INSERT INTO bonus VALUES('$data4[id_pegawai]','$tgl','$bonuspp10')";
                $resss=mysqli_query($link,$sqlll);

                $sqll1="INSERT INTO kasbon VALUES('$data4[id_pegawai]','$tgl','$kasbonp10')";
                $ress1=mysqli_query($link,$sqll1);
                // echo $data4['id_pegawai']." ".$gaji." ".$saldo."<br>";

              }
              if($data4['id_pegawai']=='pp11'){
                $bonuspp11=$_POST['bonuspp11'];
                $kasbonpp11=$_POST['kasbonpp11'];
                $gaji=$data4['gaji']+$bonuspp11-$kasbonpp11;
                $sql7="SELECT *, CONVERT(SUBSTR(kd_kasbesar,3,9), SIGNED) AS kode FROM kasbesar WHERE tanggal IN (SELECT MAX(tanggal) FROM kasbesar) ORDER BY kd_kasbesar DESC LIMIT 1";
                $res7=mysqli_query($link,$sql7);
                $data7=mysqli_fetch_array($res7);

                $kode="TD".($data7['kode']+1);
                $saldo=$data7['saldo']-$gaji;
                $keterangan1="Gaji ".$data4['nama'];
                $tanggal=date("Y-m-d H:i:s");
                $tgl=date("Y-m-d");

                $sqll="INSERT INTO kasbesar VALUES ('$kode','$tanggal','$keterangan1','0','$gaji','$saldo','RK02','PDP00000')";
                $ress=mysqli_query($link,$sqll);

                $sqlll="INSERT INTO bonus VALUES('$data4[id_pegawai]','$tgl','$bonuspp11')";
                $resss=mysqli_query($link,$sqlll);

                $sqll1="INSERT INTO kasbon VALUES('$data4[id_pegawai]','$tgl','$kasbonp11')";
                $ress1=mysqli_query($link,$sqll1);
                // echo $data4['id_pegawai']." ".$gaji." ".$saldo."<br>";

              }
              if($data4['id_pegawai']=='pp12'){
                $bonuspp12=$_POST['bonuspp12'];
                $kasbonpp12=$_POST['kasbonpp12'];
                $gaji=$data4['gaji']+$bonuspp12-$kasbonpp12;
                $sql7="SELECT *, CONVERT(SUBSTR(kd_kasbesar,3,9), SIGNED) AS kode FROM kasbesar WHERE tanggal IN (SELECT MAX(tanggal) FROM kasbesar) ORDER BY kd_kasbesar DESC LIMIT 1";
                $res7=mysqli_query($link,$sql7);
                $data7=mysqli_fetch_array($res7);

                $kode="TD".($data7['kode']+1);
                $saldo=$data7['saldo']-$gaji;
                $keterangan1="Gaji ".$data4['nama'];
                $tanggal=date("Y-m-d H:i:s");
                $tgl=date("Y-m-d");

                $sqll="INSERT INTO kasbesar VALUES ('$kode','$tanggal','$keterangan1','0','$gaji','$saldo','RK02','PDP00000')";
                $ress=mysqli_query($link,$sqll);

                $sqlll="INSERT INTO bonus VALUES('$data4[id_pegawai]','$tgl','$bonuspp12')";
                $resss=mysqli_query($link,$sqlll);

                $sqll1="INSERT INTO kasbon VALUES('$data4[id_pegawai]','$tgl','$kasbonp12')";
                $ress1=mysqli_query($link,$sqll1);
                // echo $data4['id_pegawai']." ".$gaji." ".$saldo."<br>";

              }
              if($data4['id_pegawai']=='pp13'){
                $bonuspp13=$_POST['bonuspp13'];
                $kasbonpp13=$_POST['kasbonpp13'];
                $gaji=$data4['gaji']+$bonuspp13-$kasbonpp13;
                $sql7="SELECT *, CONVERT(SUBSTR(kd_kasbesar,3,9), SIGNED) AS kode FROM kasbesar WHERE tanggal IN (SELECT MAX(tanggal) FROM kasbesar) ORDER BY kd_kasbesar DESC LIMIT 1";
                $res7=mysqli_query($link,$sql7);
                $data7=mysqli_fetch_array($res7);

                $kode="TD".($data7['kode']+1);
                $saldo=$data7['saldo']-$gaji;
                $keterangan1="Gaji ".$data4['nama'];
                $tanggal=date("Y-m-d H:i:s");
                $tgl=date("Y-m-d");

                $sqll="INSERT INTO kasbesar VALUES ('$kode','$tanggal','$keterangan1','0','$gaji','$saldo','RK02','PDP00000')";
                $ress=mysqli_query($link,$sqll);

                $sqlll="INSERT INTO bonus VALUES('$data4[id_pegawai]','$tgl','$bonuspp13')";
                $resss=mysqli_query($link,$sqlll);

                $sqll1="INSERT INTO kasbon VALUES('$data4[id_pegawai]','$tgl','$kasbonp13')";
                $ress1=mysqli_query($link,$sqll1);
                // echo $data4['id_pegawai']." ".$gaji." ".$saldo."<br>";

              }
              if($data4['id_pegawai']=='pp14'){
                $bonuspp14=$_POST['bonuspp14'];
                $kasbonpp14=$_POST['kasbonpp14'];
                $gaji=$data4['gaji']+$bonuspp14-$kasbonpp14;
                $sql7="SELECT *, CONVERT(SUBSTR(kd_kasbesar,3,9), SIGNED) AS kode FROM kasbesar WHERE tanggal IN (SELECT MAX(tanggal) FROM kasbesar) ORDER BY kd_kasbesar DESC LIMIT 1";
                $res7=mysqli_query($link,$sql7);
                $data7=mysqli_fetch_array($res7);

                $kode="TD".($data7['kode']+1);
                $saldo=$data7['saldo']-$gaji;
                $keterangan1="Gaji ".$data4['nama'];
                $tanggal=date("Y-m-d H:i:s");
                $tgl=date("Y-m-d");

                $sqll="INSERT INTO kasbesar VALUES ('$kode','$tanggal','$keterangan1','0','$gaji','$saldo','RK02','PDP00000')";
                $ress=mysqli_query($link,$sqll);

                $sqlll="INSERT INTO bonus VALUES('$data4[id_pegawai]','$tgl','$bonuspp14')";
                $resss=mysqli_query($link,$sqlll);

                $sqll1="INSERT INTO kasbon VALUES('$data4[id_pegawai]','$tgl','$kasbonp14')";
                $ress1=mysqli_query($link,$sqll1);
                // echo $data4['id_pegawai']." ".$gaji." ".$saldo."<br>";

              }
              if($data4['id_pegawai']=='pp15'){
                $bonuspp15=$_POST['bonuspp15'];
                $kasbonpp15=$_POST['kasbonpp15'];
                $gaji=$data4['gaji']+$bonuspp15-$kasbonpp15;
                $sql7="SELECT *, CONVERT(SUBSTR(kd_kasbesar,3,9), SIGNED) AS kode FROM kasbesar WHERE tanggal IN (SELECT MAX(tanggal) FROM kasbesar) ORDER BY kd_kasbesar DESC LIMIT 1";
                $res7=mysqli_query($link,$sql7);
                $data7=mysqli_fetch_array($res7);

                $kode="TD".($data7['kode']+1);
                $saldo=$data7['saldo']-$gaji;
                $keterangan1="Gaji ".$data4['nama'];
                $tanggal=date("Y-m-d H:i:s");
                $tgl=date("Y-m-d");

                $sqll="INSERT INTO kasbesar VALUES ('$kode','$tanggal','$keterangan1','0','$gaji','$saldo','RK02','PDP00000')";
                $ress=mysqli_query($link,$sqll);

                $sqlll="INSERT INTO bonus VALUES('$data4[id_pegawai]','$tgl','$bonuspp15')";
                $resss=mysqli_query($link,$sqlll);

                $sqll1="INSERT INTO kasbon VALUES('$data4[id_pegawai]','$tgl','$kasbonp15')";
                $ress1=mysqli_query($link,$sqll1);
                // echo $data4['id_pegawai']." ".$gaji." ".$saldo."<br>";

              }
            }
            echo "<script>alert('Data Berhasil Ditambahkan');
                  document.location.href='penggajian';</script>";
          }
        ?>
        </div>
      </div>
    </div>
    <!--inner block end here-->
    <!--copy rights start here-->

    <!--COPY rights end here-->
  </div>
</div>
<?php
sidemanke();
}else{
  header("Location: ../masuk.php");
}
ob_flush();
?>