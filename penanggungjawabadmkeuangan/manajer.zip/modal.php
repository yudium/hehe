<?php
session_start();
ob_start();
date_default_timezone_set('Asia/Jakarta');
include("libfunc.php");
include("../libfunc.php");
$link=koneksidb();
if(($_SESSION['logmanke']==true) && ($_SESSION['usermanke']!="")){
  $usermin=$_SESSION['usermanke'];
  $iduser=$_SESSION['idmanke'];
  $sql3="SELECT * FROM pengguna WHERE id_pengguna='$iduser'";
  $res3=mysqli_query($link,$sql3);
  $data3=mysqli_fetch_array($res3);
  headmanke();
  ?>
  <script type="text/javascript">
    function validate(){
      var error="";
      var pemasukan = document.getElementById( "pemasukan" );
      if( pemasukan.value == "" ){
        error = alert('Lengkapi Form !');
        document.getElementById( "error_para" ).innerHTML = error;
        return false;
      }
      var keterangan = document.getElementById( "keterangan" );
      if( keterangan.value == "" ){
        error = alert('Lengkapi Form !');
        document.getElementById( "error_para" ).innerHTML = error;
        return false;
      }else{
        return true;
      }
    }
  </script>
  <!--inner block start here-->
  <div class="inner-block">
    <div class="table-agile-info">
      <div class="panel panel-default">
        <div class="chit-chat-heading">
          Modal Usaha
        </div>
        <br>
        <div class="chit-chat-heading">
          <?php
          $sql="SELECT SUM(jumlahpendapatan) AS pendapatan FROM pendapatan WHERE tanggal LIKE '%2016%' AND kd_pendapatan LIKE '%PDP%'";
          $res=mysqli_query($link,$sql);
          $data=mysqli_fetch_array($res);

          $sql2="SELECT SUM(kredit) AS total FROM kasbesar k INNER JOIN jenisrekap j ON k.kd_jenisrekap=j.kd_jenisrekap WHERE tanggal LIKE '%2016%' AND k.kd_jenisrekap!='RK04' GROUP BY SUBSTR(k.kd_jenisrekap,1,2)";
          $res2=mysqli_query($link,$sql2);
          $data2=mysqli_fetch_array($res2);

          $laba=$data['pendapatan']-$data2['total'];

          $sql4="SELECT * FROM pendapatan WHERE kd_pendapatan LIKE '%PLUB%' AND SUBSTR(tanggal,1,4)='2016'";
          $res4=mysqli_query($link,$sql4);
          $data4=mysqli_fetch_array($res4);

          $sql44="SELECT * FROM pendapatan WHERE kd_pendapatan LIKE '%PLUP%' AND SUBSTR(tanggal,1,4)='2016'";
          $res44=mysqli_query($link,$sql44);
          $data44=mysqli_fetch_array($res44);

          $totlaba=$laba+$data4['jumlahpendapatan']+$data44['jumlahpendapatan'];
// echo $totlaba;
          ?>
          <table class="table table-hover">
            <thead>
              <tr>
                <th style="width:20px;"><center>No</center></th>
                <th><center>Jenis Rekap</center></th>
                <th><center>Rencana Pos Anggaran</center></th>
                <th><center>Laba 2016 Sebelum Pajak</center></th>
                <th><center>Persentase</center></th>
              </tr>
            </thead>
            <tbody>
              <?php
              $sql1="SELECT * FROM bebanperusahaan p INNER JOIN detilbebanperusahaan d ON p.kd_bebanperusahaan=d.kd_bebanperusahaan INNER JOIN jenisrekap j ON d.kd_jenisrekap=j.kd_jenisrekap WHERE p.kd_bebanperusahaan LIKE '%2017%'";
              $res1=mysqli_query($link,$sql1);
              $i=1;
              while($data1=mysqli_fetch_array($res1)){
                $pers=$data1['jumlahbebanperusahaan']/$totlaba*100;
                $ar[$i]=$data1['jumlahbebanperusahaan'];
                $ar1[$i]=$pers;
                ?>
                <tr>
                  <td><center><?php echo $i;?></center></td>
                  <td><center><?php echo strtoupper($data1['jenisrekap']);?></center></td>
                  <td><center><?php echo "Rp ".strtoupper(number_format($data1['jumlahbebanperusahaan']));?></center></td>
                  <td><center><?php echo "Rp ".strtoupper(number_format($totlaba));?></center></td>
                  <td><center><?php echo round($pers,2)." %"; ?></center></td>
                </tr>
                  <?php
                  $i++;
                }
                $totalbeban=array_sum($ar);
                $totalpers=array_sum($ar1);
                $pkas=100-$totalpers;
              $kas=($pkas/100)*$totalbeban;
              ?>
              <tr>
                <td colspan="2"><center>TOTAL</center></td>
                <td><center><?php echo "Rp ".strtoupper(number_format($totalbeban));?></center></td>
                <td><center><?php echo "Rp ".strtoupper(number_format($totlaba));?></center></td>
                <td><center><?php echo round($totalpers,2)." %"; ?></center></td>
              </tr>
              <tr>
                <td colspan="2"><center>KAS</center></td>
                <td><center><?php echo "Rp ".strtoupper(number_format($kas));?></center></td>
                <td><center><?php echo "Rp ".strtoupper(number_format($totlaba));?></center></td>
                <td><center><?php echo round($pkas,2)." %"; ?></center></td>
              </tr>
              </tbody>
            </table>
          </center>
        </div>
      </div>
    </div>
  </div>
    <!--inner block end here-->
    <!--copy rights start here-->

    <!--COPY rights end here-->
  </div>
</div>
<?php
sidemanke();
}else{
  header("Location: ../masuk.php");
}
ob_flush();
?>