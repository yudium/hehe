<?php
	session_start();
  ob_start();
  include("libfunc.php");
  include("../libfunc.php");
  $link=koneksidb();
  if(($_SESSION['logmanke']==true) && ($_SESSION['usermanke']!="")){
  	$kdjen=base64_decode($_GET['fdwDWWD']);
  	$sql3="DELETE FROM jenisrekap WHERE kd_jenisrekap='$kdjen'";
    $res3=mysqli_query($link,$sql3);
    echo "<script>alert('Data Berhasil Dihapus');
            document.location.href='jenisrekap';</script>";
  }else{
    header("location:..\loginfirst.php");
	}
?>