<?php
session_start();
ob_start();
date_default_timezone_set('Asia/Jakarta');
include("libfunc.php");
include("../libfunc.php");
$link=koneksidb();
if(($_SESSION['logmanke']==true) && ($_SESSION['usermanke']!="")){
  $usermin=$_SESSION['usermanke'];
  $iduser=$_SESSION['idmanke'];
  $sql3="SELECT * FROM pengguna WHERE id_pengguna='$iduser'";
  $res3=mysqli_query($link,$sql3);
  $data3=mysqli_fetch_array($res3);
  headmanke();
  ?>
  <script type="text/javascript">
    function validate(){
      var error="";
      var tahun = document.getElementById( "tahun" );
      if( tahun.value == "" ){
        error = alert('Lengkapi Form !');
        document.getElementById( "error_para" ).innerHTML = error;
        return false;
      }else{
        return true;
      }
    }
  </script>
  <!--inner block start here-->
  <div class="inner-block">
    <div class="table-agile-info">
      <div class="panel panel-default">
        <form class="form-horizontal style-form" role="form" method="post" action="" onsubmit="return validate();">
          <h5><i class="fa "></i>Tahun</h5>
          <br>
          <select class="form-control" name="tahun" id="tahun">
            <option value="">Pilih</option>
            <?php 
            $sql2="SELECT * FROM bebanperusahaan ORDER BY tahun";
            $res2=mysqli_query($link,$sql2);
            while($data2=mysqli_fetch_array($res2)){
              echo "<option value='$data2[tahun]'>$data2[tahun]</option>";
            }
            ?>
          </select>
          <br>
          <input type="submit" value="Proses" name="submit" class="btn btn-default">           
          <br>
        </form>
        <p style="display:none" id="error_para"></p>
        <br>
        <br>
        <?php 
          if (isset($_POST["submit"])){
            $tahun=$_POST['tahun'];
            ?>
            <br>
            <div class="main-page-charts">
              <div class="main-page-chart-layer1">
                <div class="col-md-6 chart-layer1-left"> 
                  <div class="glocy-chart">
                    <div class="chit-chat-heading">
                      Grafik Kas Besar Terhadap Rencana Beban Biaya Tahun <?php  echo $tahun."<br>";?>
                    </div>
                    <br>
                    <div class="span-2c">
                      <canvas id="bar" height="600" width="800" style="width: 800px; height: 600px;"></canvas>
                      <script>
                        var barChartData = {
                          //labels : ["Beban Belanja Bahan Baku","Beban Gaji","Beban Makan & Minum","Beban Suplies Kantor","Beban Komputer & IT","Beban Fotocopy & ATK","Beban Listrik","Beban Komunikasi","Beban BBM, Parkir & Tol","Beban Kantor Lainnya","Beban Gaji Luar Karyawan",],
                          labels : ["1","2","3","4","5","6","7","8","9","10","11"],
                          // <?php
                          //   $sql5="SELECT * FROM jenisrekap ORDER BY kd_jenisrekap";
                          //   $res5=mysqli_query($link,$sql5);
                          //   while($data5=mysqli_fetch_array($res5)){
                          //     echo $data5['jenisrekap'].",";
                          //   }
                          // ?>
                          
                          datasets : [
                          {
                            fillColor : "#FC8213",
                            data : [
                            <?php
                            $sql1="SELECT * FROM bebanperusahaan WHERE tahun='$tahun'";
                            $res1=mysqli_query($link,$sql1);
                            $data1=mysqli_fetch_array($res1);
                            $sql4="SELECT * FROM detilbebanperusahaan WHERE kd_bebanperusahaan='$data1[kd_bebanperusahaan]' ORDER BY kd_jenisrekap";
                            $res4=mysqli_query($link,$sql4);
                            $i=1;
                            while($data4=mysqli_fetch_array($res4)){
                              echo $data4['jumlahbebanperusahaan'].",";
                              $pos[$i]=$data4['jumlahbebanperusahaan'];
                              $i++;
                            }
                            // 65,59,90,81,56,55,45,90,81,56,55,45,
                            ?>
                            ]
                          },
                          {
                            fillColor : "#337AB7",
                            data : [
                            <?php
                            $sql6="SELECT *, SUM(kredit) AS kreditt FROM `kasbesar` WHERE tanggal LIKE '%$tahun%' AND kd_jenisrekap!='RK04' GROUP BY kd_jenisrekap ORDER BY kd_jenisrekap";
                            $res6=mysqli_query($link,$sql6);
                            $j=1;
                            while($data6=mysqli_fetch_array($res6)){
                              echo $data6['kreditt'].",";
                              $kre[$j]=$data6['kreditt'];
                              $j++;
                            }
                            // 65,59,90,81,56,55,45,90,81,56,55,45,
                            ?>
                            ]
                          }
                          ]

                        };
                        new Chart(document.getElementById("bar").getContext("2d")).Bar(barChartData);

                      </script>
                      <br>
                      <br>
                      <span class="label label-danger">&nbsp</span> Pos Beban<br>
                      <span class="label label-info">&nbsp</span> Realisasi
                    </div>                    
                  </div>
                </div>
                <div class="col-md-6 chart-layer1-right"> 
                  <div class="work-progres">
                  Keterangan : <br>
                  &nbsp&nbsp 1 : <a target="_blank" href="monitoringbeban?CNgjefbw=<?php echo base64_encode($tahun); ?>&bkfwFWv=<?php echo base64_encode("RK01"); ?>">
                    Beban Belanja Bahan Baku </a><br>
                  &nbsp&nbsp 2 : <a target="_blank" href="monitoringbeban?CNgjefbw=<?php echo base64_encode($tahun); ?>&bkfwFWv=<?php echo base64_encode("RK02"); ?>">
                    Beban Gaji</a> <br>
                  &nbsp&nbsp 3 : <a target="_blank" href="monitoringbeban?CNgjefbw=<?php echo base64_encode($tahun); ?>&bkfwFWv=<?php echo base64_encode("RK03"); ?>">
                    Beban Makan & Minum </a> <br>
                  &nbsp&nbsp 4 : <a target="_blank" href="monitoringbeban?CNgjefbw=<?php echo base64_encode($tahun); ?>&bkfwFWv=<?php echo base64_encode("RK05"); ?>">
                    Beban Suplies Kantor </a><br>
                  &nbsp&nbsp 5 : <a target="_blank" href="monitoringbeban?CNgjefbw=<?php echo base64_encode($tahun); ?>&bkfwFWv=<?php echo base64_encode("RK07"); ?>">
                    Beban Komputer & IT </a><br>
                  &nbsp&nbsp 6 : <a target="_blank" href="monitoringbeban?CNgjefbw=<?php echo base64_encode($tahun); ?>&bkfwFWv=<?php echo base64_encode("RK08"); ?>">
                    Beban Foto Copy & ATK </a><br>
                  &nbsp&nbsp 7 :<a target="_blank" href="monitoringbeban?CNgjefbw=<?php echo base64_encode($tahun); ?>&bkfwFWv=<?php echo base64_encode("RK09"); ?>"> 
                    Beban Listrik </a><br>
                  &nbsp&nbsp 8 : <a target="_blank" href="monitoringbeban?CNgjefbw=<?php echo base64_encode($tahun); ?>&bkfwFWv=<?php echo base64_encode("RK10"); ?>">
                    Beban Komunikasi </a><br>
                  &nbsp&nbsp 9 : <a target="_blank" href="monitoringbeban?CNgjefbw=<?php echo base64_encode($tahun); ?>&bkfwFWv=<?php echo base64_encode("RK12"); ?>">
                    Beban BBM,Parkir Dan Tol </a><br>
                  &nbsp&nbsp 10 : <a target="_blank" href="monitoringbeban?CNgjefbw=<?php echo base64_encode($tahun); ?>&bkfwFWv=<?php echo base64_encode("RK13"); ?>">
                    Beban Kantor Lainnya </a><br>
                  &nbsp&nbsp 11 : <a target="_blank" href="monitoringbeban?CNgjefbw=<?php echo base64_encode($tahun); ?>&bkfwFWv=<?php echo base64_encode("RK17"); ?>">
                    Beban Gaji Luar Karyawan </a><br>
              </div>
                </div>
                <div class="clearfix"> </div>
              </div>

              <br>
              <div class="main-page-chart-layer1">
                <div class="col-md-12 chart-layer1-left"> 
                  <div class="work-progres">
                <div class="table-responsive">
                  <table class="table table-hover">
                    <thead>
                      <tr>
                        <th rowspan="2"><center>No</center></th>
                        <th rowspan="2"><center>Pos Beban</center></th>
                        <th rowspan="2"><center>Terealisasi</center></th>
                        <th rowspan="2"><center>Rencana</center></th>
                        <th rowspan="2"><center>Persentase</center></th>
                        <th rowspan="2"><center>Status</center></th>
                        <th rowspan="2"><center>Pemberitahuan</center></th>
                        <th colspan="3"><center>Selisih/Varians</center></th>
                      </tr>
                      <tr>
                        <th><center>Rupiah</center></th>
                        <th><center>%</center></th>
                        <th><center>U/F</center></th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $sql6="SELECT * FROM jenisrekap WHERE kd_jenisrekap!='RK04' ORDER BY kd_jenisrekap";
                        $res6=mysqli_query($link,$sql6);
                        $k=1;
                        while($data6=mysqli_fetch_array($res6)){
                          $persen=round(($kre[$k]/$pos[$k]*100),2);
                          ?>
                        <tr>
                          <td><?php echo $k; ?></td>
                          <td><?php echo $data6['jenisrekap']; ?></td>
                          <td><?php echo "Rp ".number_format($kre[$k]); ?></td>
                          <td><?php echo "Rp ".number_format($pos[$k]); ?></td>
                          <td><center><?php echo $persen." %"; ?></center></td>
                          <td><center><?php 
                            $min=ceil($pos[$k]*0.8);
                            if($kre[$k]>=$min && $kre[$k]<$pos[$k]){
                              echo "<span class='label label-warning'>Mendekati</span>";
                            }else if($kre[$k]>=$pos[$k]){
                              echo "<span class='label label-warning'>Tidak Aman</span>";
                            }else{
                              echo "-";
                            }
                           ?></center></td>
                           <td><center><?php 
                            $min=ceil($pos[$k]*0.8);
                            if($kre[$k]>=$pos[$k])
                              echo "<span class='label label-warning'>audit</span>";
                            else
                              echo "-";
                           ?></center></td>
                          <td><center><?php 
                            $has=$pos[$k]-$kre[$k];
                            if($has>0 || $has<0)
                              echo "Rp ".number_format($has);
                            else
                              echo "-";
                          ?></center></td>
                          <td><center><?php 
                            $perc=($has/$pos[$k])*100;
                            echo round($perc,2)." %";
                          ?></center></td>
                          <td><center><?php
                            if($perc>=0)
                              echo "U";
                            else
                              echo "F";
                          ?></center></td>
                        </tr>
                          <?php
                          $k++;
                          $has=0;
                          $perc=0;
                        }

                         ?>
                    </tbody>
                  </table>
                </div>
              </div>
                </div>
                <div class="clearfix"> </div>
              </div>


            </div>
            <br>
            <?php
          }
         ?>
        </div>
      </div>
    </div>
    <!--inner block end here-->
    <!--copy rights start here-->

    <!--COPY rights end here-->
  </div>
</div>
<?php
sidemanke();
}else{
  header("Location: ../masuk.php");
}
ob_flush();
?>